export function Content() {
  // Complete aqui
}